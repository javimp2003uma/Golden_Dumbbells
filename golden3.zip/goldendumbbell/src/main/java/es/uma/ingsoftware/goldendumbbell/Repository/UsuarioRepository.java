package es.uma.ingsoftware.goldendumbbell.Repository;

import es.uma.ingsoftware.goldendumbbell.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

}