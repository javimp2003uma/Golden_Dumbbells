package es.uma.ingsoftware.goldendumbbell.Service;

import es.uma.ingsoftware.goldendumbbell.Repository.UsuarioRepository;
import es.uma.ingsoftware.goldendumbbell.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class usuarioService {

    @Autowired
    UsuarioRepository usuarioRepository;

    public List<Usuario> getAll() {
        return usuarioRepository.findAll();
    }

    public void save(Usuario p) {
        usuarioRepository.saveAndFlush(p);
    }

    public void delete(Integer id) {
        usuarioRepository.deleteById(id);
    }

    public Usuario getById(Integer id) {
        return usuarioRepository.getOne(id);
    }
}