package es.uma.ingsoftware.goldendumbbell.model;

import java.util.Date;
import java.util.List;
import java.util.Map;


public class Clase {

    Map<String,Map<Date,List<Usuario>>> horario;  //No se pueden poner duplas se me ha ocurrido crear otra clase pero no sé
    //Otra cosa que se me ha ocurrido es que como el int indica el numero de gente podemos devolver el tamaño de la lista
    int maxPersonas;

    public Clase(){

    }

}
