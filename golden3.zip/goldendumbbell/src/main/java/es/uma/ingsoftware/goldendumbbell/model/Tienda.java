package es.uma.ingsoftware.goldendumbbell.model;

import java.util.List;

public class Tienda {
    //Nada más hay tienda no base de datos
    List<Producto> productosTienda;

    public Tienda(){

    }

    public List<Producto> getProductosTienda() {
        return productosTienda;
    }

    //Hace falta crear el toSringde una lista
}
