package es.uma.ingsoftware.goldendumbbell.controller;

import ch.qos.logback.core.model.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PersonaController {

    @Autowired
    UsuarioService usuarioService;

    @RequestMapping("/personas")
    public String listadoPersonas(Model model) {
        List<Usuario> personas = usuarioService.getAll();

        model.addAttribute("listaPersonas", personas);

        return "personas/index";
    }

    @RequestMapping("/personas/add")
    public String addPersona(Model model) {
        model.addAttribute("persona", new Usuario());
        return "personas/add";
    }

    @PostMapping("/personas/save")
    public String savePersona(Persona p) {
        personaService.save(p);
        return "redirect:/personas";
    }

    @RequestMapping("/personas/edit/{id}")
    public String editPersona(@PathVariable("id") Integer id, Model model) {
        model.addAttribute("persona", personaService.getById(id));
        return "personas/add";
    }

    @RequestMapping("/personas/view/{id}")
    public String viewPersona(@PathVariable("id") Integer id, Model model) {
        model.addAttribute("persona", personaService.getById(id));
        return "personas/view";
    }

    @RequestMapping("/personas/delete/{id}")
    public String deletePersona(@PathVariable("id") Integer id) {
        personaService.delete(id);
        return "redirect:/personas";
    }
}