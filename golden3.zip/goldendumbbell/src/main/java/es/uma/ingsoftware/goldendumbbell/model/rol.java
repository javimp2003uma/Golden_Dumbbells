package es.uma.ingsoftware.goldendumbbell.model;

public enum rol{
    INVITADO,PREMIUM,USUARIO
}
