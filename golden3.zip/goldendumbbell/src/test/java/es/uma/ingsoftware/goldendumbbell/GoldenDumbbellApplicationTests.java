package es.uma.ingsoftware.goldendumbbell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoldenDumbbellApplicationTests {

	@Test
	void contextLoads() {
	}

}
