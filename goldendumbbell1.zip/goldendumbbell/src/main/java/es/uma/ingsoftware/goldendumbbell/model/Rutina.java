package es.uma.ingsoftware.goldendumbbell.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.util.List;
import java.util.Map;

@Entity
public class Rutina {

    @Id
    @GeneratedValue
    private int id;
    private String nombreRutina;
    //private Map<String, List<Ejercicio>> dias;

    public Rutina(){

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreRutina() {
        return nombreRutina;
    }

    public void setNombreRutina(String nombreRutina) {
        this.nombreRutina = nombreRutina;
    }

    public void addEjercicio(String s, Ejercicio e){
        //Cuando coincida añades el ejercicio
    }
}
