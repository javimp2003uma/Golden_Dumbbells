package es.uma.ingsoftware.goldendumbbell;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldenDumbbellApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoldenDumbbellApplication.class, args);
	}

}
