package es.uma.ingsoftware.goldendumbbell.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

import java.awt.*;
import java.util.List;
import java.util.Objects;

@Entity
public class Salud {

    @Id
    @GeneratedValue
    int id;
    private String titulo;
    private Image foto;
    private String descripcion;
    //private List<Rutina> rutinasrecomendada;


    public Salud(){

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Image getFoto() {
        return foto;
    }

    public void setFoto(Image foto) {
        this.foto = foto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /* public List<Rutina> getRutinasrecomendada() {
        return rutinasrecomendada;
    }

   public void setRutinasrecomendada(List<Rutina> rutinasrecomendada) {
        this.rutinasrecomendada = rutinasrecomendada;
    }

    public void addRutinaRecomendada(Rutina r){
        rutinasrecomendada.add(r);
    }
*/
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Salud salud)) return false;
        return getId() == salud.getId() && Objects.equals(getTitulo(), salud.getTitulo());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getTitulo());
    }

}
