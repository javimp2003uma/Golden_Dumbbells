package es.uma.ingsoftware.goldendumbbell.model;

import java.util.List;
import java.util.Map;
public class Dieta {
    private Map<String, List<String>> dieta;

    //EN el diagrama de clases hay un tipo comida que no entiendo muy bien lvrd

    public Dieta(){

    }

}
