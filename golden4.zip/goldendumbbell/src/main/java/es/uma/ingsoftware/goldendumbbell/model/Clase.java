package es.uma.ingsoftware.goldendumbbell.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class Clase {
    private String name;
    private Date hora;
    private List<Usuario> usuarios;

    public String getName() {
        return name;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public Date getHora() {
        return hora;
    }

    public void setName(String name) {
        this.name = name;
    }


    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }


    public Clase(String name, Date hora) {
        this.name = name;
        this.hora = hora;
        usuarios = new ArrayList<>();
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Clase clase = (Clase) o;
        return Objects.equals(name, clase.name) && Objects.equals(hora, clase.hora);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, hora);
    }
}
