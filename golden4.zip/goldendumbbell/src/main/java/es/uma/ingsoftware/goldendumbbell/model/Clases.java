package es.uma.ingsoftware.goldendumbbell.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;


public class Clases {

    List<Clase> horario;

    //Map<String,Map<Date,List<Usuario>>> horario;  //No se pueden poner duplas se me ha ocurrido crear otra clase pero no sé
    //Otra cosa que se me ha ocurrido es que como el int indica el numero de gente podemos devolver el tamaño de la lista
    int maxPersonas;

    public List<Date> filtrarNombre(String n){
        List<Date> res = new ArrayList<>();

        for(Clase c : horario){
            if(n.equalsIgnoreCase(c.getName())){
                res.add(c.getHora());
            }
        }

        return res;
    }

    public List<String> filtrarHora(Date h){
        List<String> res = new ArrayList<>();

        for(Clase c : horario){
            if(h.equals(c.getHora())){
                res.add(c.getName());
            }
        }

        return res;
    }

    public boolean estaVacia(String n, Date h){
        boolean res = true;
        Clase c = buscarClase(n,h);
        return c.getUsuarios().isEmpty();
    }

    private Clase buscarClase(String n, Date h) {
        Clase aux = new Clase(n,h);
        for(Clase c : horario){
            if(c.equals(aux)){
                return c;
            }
        }
        throw new RuntimeException("No existe la clase");
    }

    public Clases(){

    }

}
