package es.uma.ingsoftware.goldendumbbell.model;

import java.util.List;
import java.util.Map;
public class Dieta {
    private Map<String, List<String>> dieta;

    //EN el diagrama de clases hay un tipo comida que no entiendo muy bien lvrd

    public Dieta(){

    }

    public void addAlimento(String a,String l){
        //Cuando a coincida con el String del mapa añado l a la lista
    }
    //Lo mismo con un metodo borrar alimento

}
